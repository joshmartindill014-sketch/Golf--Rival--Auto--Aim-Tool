# Golf Rival Auto Aim — phone-friendly GitHub build

This repository includes a GitHub Actions workflow that builds the Android debug APK in the cloud.

## Build from your phone

1. Create/sign into a GitHub account.
2. Create a new repository, e.g. `golf-rival-auto-aim`.
3. Upload the contents of this folder to the repository (not the ZIP file inside another ZIP).
4. Make sure `.github/workflows/build-apk.yml` is present.
5. Open the repository's **Actions** tab.
6. Select **Build Golf Rival Auto Aim APK**.
7. Tap **Run workflow**.
8. Wait for the green check.
9. Open the completed workflow run and scroll to **Artifacts**.
10. Download `Golf-Rival-Auto-Aim-debug`, unzip it, and install `app-debug.apk`.

GitHub Actions runs the build on a GitHub-hosted runner. The workflow uses Gradle and Android SDK tooling and uploads the resulting APK as an artifact.

## Important prototype limitation

This is an early calibration build. It reads the wind number from the upper-right region based on the supplied Golf Rival screenshot, but the direction/club/elevation correction is not yet fully calibrated. Do not assume the overlay is accurate for competitive shots until it has been tested against several screenshots.

## Permissions

The app needs Android screen-capture permission and permission to display over other apps. These are normal Android permissions for this type of overlay/screen-reading utility.
